Components folder:

    Should contain all of your components.

    Exmaple 'my-compoent.scss'

    In another case, if you need media styles for your component then you should create
    a folder in the 'components' directory and name it with the name of your component

    For rest info go to 'demo-component' folder and read readme.md file there
